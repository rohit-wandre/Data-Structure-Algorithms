public class Main
{
	public static void main(String[] args) {
		int a=2,n=8;
		int s=1;
		for(int i=1;i<=n;i++)
		{
		    s=s*a;
		}
		System.out.println(s);
	}
}
