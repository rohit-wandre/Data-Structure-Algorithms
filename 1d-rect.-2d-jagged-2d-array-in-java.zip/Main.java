import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		
	   Scanner kb=new Scanner(System.in);
	   //int n,sum=0;
	   //System.out.println("Enter size");
	   //n=kb.nextInt();
	   
	   //int arr[]=new int[n];
	   //for(int i=0;i<n;i++)
	   //{
	   //    System.out.println("Enter "+(i+1)+" number:");
	   //    arr[i]=kb.nextInt();
	   //    sum+=arr[i];
	   //}
	   //double avg;
	   //avg=sum/n;
	   //System.out.println("Sum is: "+sum+"\naverage is: "+avg);
	  
// 	  int n=args.length;
// 	  int sum=0;
	  
// 	  if(n<=1)
// 	  {
// 	      System.out.println("Please enter two numbers!");
// 	      System.exit(0);
// 	  }
	  
// 	  for(int i=0;i<n;i++)
// 	  {
// 	      sum+=Integer.parseInt(args[i]);
// 	  }
	  
// 	  System.out.println("Sum is:"+sum);
		
		
//-------------------------------------------------RECTANGULAR 2D ARRAY------------------------------------------------------------		
		
// 		int r=2,c=2;
		
// 		int arr[][]=new int[r][c];
		
// 		for(int i=0;i<arr.length;i++)
// 		{
// 		    for(int j=0;j<arr[i].length;j++)
// 		    {
// 		        arr[i][j]=kb.nextInt();
// 		    }
// 		}
		
// 		for(int i=0;i<r;i++)
// 		{
// 		    for(int j=0;j<c;j++)
// 		    {
// 		        System.out.print(arr[i][j]+" ");
// 		    }
// 		    System.out.println();
// 		}
	
	
	
// ----------------------------------------- JAGGED 2D ARRAY-----------------------------------------------------------------	
	
	
		
// 		int c;
// 		int arr[][]=new int[2][];
// 		for(int i=0;i<arr.length;i++)
// 		{
//  	            System.out.println("Enter no of columns for "+(i+1)+" row");
//  	            c=kb.nextInt();
//  	            arr[i]=new int[c];
//  	            System.out.println("Enter values");
//  	            for(int j=0;j<arr[i].length;j++)
//  	            {
//  	                arr[i][j]=kb.nextInt();
//  	            }
// 		}
		
// 		for(int i=0;i<arr.length;i++)
// 		{
// 		    int sum=0;
// 		    for(int j=0;j<arr[i].length;j++)
// 		    {
// 		        sum+=arr[i][j];
// 		        System.out.print(arr[i][j]+" ");
// 		    }
// 		    System.out.println("Sum is: "+sum);
		   
// 		}
		
		
		
		
		
		
		
		
		
	}
}
