public class Main
{
	public static void main(String[] args) {
		int base=2,a=4,res=1;
// 		while(a>0)
// 		{
// 		    res=base*res;
// 		    a--;
// 		}

  for(int i=1;i<=a;i++)
  {
      res=base*res;
  }


		System.out.print(res);
	}
}
